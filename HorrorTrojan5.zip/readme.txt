Malware name: HorrorTrojan 5.0
type: CreepyPasta Trojan
damage rate: destructive
made in: vb6, c++, c#, asm
works in: WinVista and newer
Do not run on real pc, use a vm